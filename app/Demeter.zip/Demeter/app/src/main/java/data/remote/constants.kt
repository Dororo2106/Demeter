package data.remote

object constants {
}