package data.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class UserRequest {
    @SerializedName ("Numero de Celular")
    @Expose
    var num: String? = null

    @SerializedName("contraseña")
    @Expose
    var contraseña: String? = null
}