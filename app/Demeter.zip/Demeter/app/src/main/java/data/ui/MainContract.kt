package data.ui

interface MainContract {
   interface View{

    }
    interface Presenter{
    }
}
